from random import randint

print('-' * 50)
print('Vamos jogar PAR ou IMPAR?')
print('-' * 50)

qtdvit = 0
while True:
    jogador = int(input('Digite um valor:'))
    computador = randint (0, 10)
    total = jogador + computador
    opcao = ' '
    while opcao not in 'PI':
        opcao = str(input("PAR ou IMPAR? [P/I]: ")).strip() .upper() [0]

        print(f'Você jogou {jogador} e o computador jogou {computador}. O total foi de {total}. ')
        print('Deu PAR.' if total % 2 == 0 else 'Deu IMPAR.')
        print('-' * 50)

        if opcao == 'P':
            if total % 2 == 0:
                print('Você venceu!')
                qtdvit += 1
            else:
                print('Você perdeu!')
                break
        elif opcao == 'I':
            if total % 2 == 1:
                print('Você venceu!')
                qtdvit += 1
            else:
                print('Você perdeu!')
                break
        else:
            print('Opção errada. Tente novamente!')

print('-' * 50)
if qtdvit == 0:
    print('Tente novamente. Você não conseguiu vencer o computador.')
else:
    print(f'Você conseguiu {qtdvit} vitória(s) consecutiva(s).')
print('-' * 50)