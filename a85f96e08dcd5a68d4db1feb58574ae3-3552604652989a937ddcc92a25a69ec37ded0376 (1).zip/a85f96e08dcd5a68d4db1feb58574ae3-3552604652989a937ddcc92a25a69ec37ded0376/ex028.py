#Crie um programa que leia duas notas de um aluno e calcule sua média, mostrando uma
#mensagem no final, de acordo com a média atingida:
# Média abaixo de 5.0: REPROVADO
# Média entre 5.0 e 6.9: RECUPERAÇÃO
# Média acima ou igual a 7.0: APROVADO

nota1 = float(input('Informe a primeira nota do aluno:'))
nota2 = float(input('Informe a segunda nota do aluno: '))

media = (nota1 + nota2) / 2

if media < 5.0:
    print('A media final do aluno foi {}. O aluno foi REPROVADO!'.format(media))
elif media >=7.0:
    print('A media final do aluno foi {}. O aluno foi APROVADO!'.format(media))
else:
    print('A media final do aluno foi {}. O aluno ficará de RECUPERAÇÃO!'.format(media))