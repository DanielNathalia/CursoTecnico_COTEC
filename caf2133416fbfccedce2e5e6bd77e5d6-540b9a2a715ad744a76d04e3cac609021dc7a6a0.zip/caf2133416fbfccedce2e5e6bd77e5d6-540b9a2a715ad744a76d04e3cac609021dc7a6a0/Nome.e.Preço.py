preco = 0
pdt = 0
total = totmil = menor = cont = 0
barrato = ' '
while True:
    pdt = str(input('Informe o nome do produto:'))
    preco = float(input('Informe o preço do produto:'))
    cont += 1
    total += preco
    if preco > 1000:
        totmil += 1
    if cont == 1 or preco < menor:
      menor =  preco
      barato = pdt
    else:
        if preco < menor:
           menor = preco
           barato = pdt
    resp = ' '
    while resp not in 'SN':
        resp = str(input('Quer continuar? [S/N]:')).strip().upper()[0]
    if resp == 'N':
        break

print('-' * 50)
print(f'A soma dos produtos é de R${total:.2f}')
print(f"Tem {totmil} acima de R$1000")
print(f'O produto de menor preço foi {barato}, e custa R${menor:.2f}')
print('{:-^50}'. format('Saindo do programa!'))