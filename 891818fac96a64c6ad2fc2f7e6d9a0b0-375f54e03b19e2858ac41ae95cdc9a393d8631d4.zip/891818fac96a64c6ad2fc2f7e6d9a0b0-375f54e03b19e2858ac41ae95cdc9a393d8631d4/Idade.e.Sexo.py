totall8 = totHomens = totMulher20 = 0

while True:
    idade = int(input('Idade:'))
    sexo = ' '
    while sexo not in 'MF':
        sexo = str(input('Sexo: [F/M]:')).strip() .upper() [0]
    if idade > 18:
        totall8 += 1
    if sexo == 'M':
        totHomens += 1
    if sexo == 'F' and idade < 20:
        totMulher20 += 1
    resp = ' '
    while resp not in 'SN':
        resp = str(input('Quer continuar? [S/N]:')).strip() .upper() [0]
    if resp == 'N':
        break
print('-' * 50)
print(f'Foram cadastrados  {totall8} pessoas com mais de 18 anos.')
print(f'Fora cadastrados {totHomens} homens.')
print(f'Foram cadastrados {totMulher20} mulher (es) com mais de 20 anos.')
print('-' * 50)
print('Saindo do programa!')