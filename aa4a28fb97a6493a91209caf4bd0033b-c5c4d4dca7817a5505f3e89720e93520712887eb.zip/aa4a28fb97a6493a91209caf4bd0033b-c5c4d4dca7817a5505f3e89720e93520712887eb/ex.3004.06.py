
num = cont = soma = 0
while num != 999:
    num = int(input('Digite um número: [digite 999 para sair]'))

    cont += 1
    soma += num
    total = soma - 999

print('Você digitou {} números e a soma entre eles foi {}'.format(cont, total))