Vnumero =  int(input("Insira um numero:"))

print("-" * 60)
antecessor = Vnumero - 1
print("Seu antecessor é ", format(antecessor))

sucessor = Vnumero + 1
print("Seu sucessor é ", format(sucessor))
print("-" * 60)