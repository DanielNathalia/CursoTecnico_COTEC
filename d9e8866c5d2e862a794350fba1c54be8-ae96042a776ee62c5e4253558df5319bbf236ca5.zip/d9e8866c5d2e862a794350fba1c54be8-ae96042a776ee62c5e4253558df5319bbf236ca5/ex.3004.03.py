val1 = int(input("Digite o valor 1:"))
val2 = int(input("Digite o valor 2:"))

opcao = 1

while opcao != 3:
    print('''
        [1] subtrair
        [2] dividir
        [3] sair do programa 
''')
    print('-' * 80)
    opcao = int(input('Selecione a opção desejada:'))

    if opcao == 1:
       subtracao = val1 - val2
       print('A subtração entre {} e {} é igual a {}'.format(val1, val2, subtracao))

    elif opcao == 2:
         divisao = val1 / val2
         print('A divisão entre {} e {} é igual a {}'.format(val1, val2, divisao))

    elif opcao == 3:
         print('Saindo do programa...')

    else:
       print('Opção inválida. Tente novamente!')
