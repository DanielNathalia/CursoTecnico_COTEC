from math import factorial

num1 = int(input('Digite um número para o cálculo do fatorial(digite 0 para sair):'))
c = num1
f = 1
print('Calculando {}!'.format(num1), end='')
while c != 0:
    print('{}'.format(c), end='')
    print('x' if c > 1  else '=', end='')
    f *= c
    c -= 1
print('{}'.format(f))
if num1 == 0:
 print('Saindo do programa...')



