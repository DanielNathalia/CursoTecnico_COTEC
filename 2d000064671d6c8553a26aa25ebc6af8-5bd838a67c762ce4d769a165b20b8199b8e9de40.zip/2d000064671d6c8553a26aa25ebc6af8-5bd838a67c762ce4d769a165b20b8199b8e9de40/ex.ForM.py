sexo = str(input('Informe seu sexo [F/M]:')).strip() .upper()[0]

while sexo not in 'mfMF':
    sexo = str(input('Informação incorreta. Por favor, informe novamente:'))
print('O sexo {} foi informado com sucesso'.format(sexo))




