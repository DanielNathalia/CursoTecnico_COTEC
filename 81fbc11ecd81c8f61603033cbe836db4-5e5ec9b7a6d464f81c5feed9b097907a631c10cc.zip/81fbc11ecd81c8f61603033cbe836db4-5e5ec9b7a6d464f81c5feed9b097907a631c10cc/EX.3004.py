print('-'*80)
val1 = int(input('Digite o valor 1:'))
val2 = int(input('Digite o valor 2:'))

opcao = 1

while opcao != 0:
    print(print('-'*80))
    print('''
    [1] Somar
    [2] Subtrair
    [3] Multiplicação
    [4] Divisão
    [5] Menor
    [6] Maior
    [7] Novos números
    [0] Sair do programa
    ''')
    print('-'*80)
    opcao = int(input('Selecione a opção desejada:'))

    if opcao == 1:
        print('A SOMA entre {} e {} é igual a {}'.format(val1, val2, val1 + val2))
    elif opcao == 2:
        print('A SUBTRAÇÃO entre {} e {} é igual a {}'.format(val1, val2, val1 - val2))
    elif opcao == 3:
        print('A MULTIPLICAÇÃO entre {} e {} é igual a {}'.format(val1, val2, val1 * val2))
    elif opcao == 4:
        print('A DIVISÃO entre {} e {} é igual a {}'.format(val1, val2, val1 / val2))
    elif opcao == 5:
        if val1 > val2:
            maior = val1
        else:
            maior = val2
        print('Entre {} e {} o maior valor é {}'.fotmat(val1, val2, maior))
    elif opcao == 6:
        if val1 < val2:
            menor = val1
        else:
            menor = val2
        print('Entre {} e {} o maior valor é {}'.fotmat(val1, val2, menor))
    elif opcao == 7:
        print('Informe o valor novamente!')
        val1 = int(input('Digite o valor 1:'))
        val2 = int(input('Digite o valor 2:'))
    elif opcao == 0:
        print('Opção inválida. Tente novamente!')
    print('-'*80)
