#exercício 1
#Escrever um program ue leia um numero inteiro qualquer e
#mostre na tela se ele é par ou impar

print('-'* 60)
numero = int(input("Digite um número inteiro:"))
#print('O numero digitado foi {}'.format(numero))

resultado = numero % 2
#print('O resto da divisão de {} por 2 é {}'.format(numero, resultado))

#se for par mostre a mensagem falando que o numero xx é par
#senao f mostre a mensagem falando que o numero xx é par

if resultado == 0 :
    print('O numero {} é par!'.format(numero))
else:
    print('O numero {} é impar!'.format(numero))

print('-'* 60)
print('Verificação concluída!')
print('-'* 60)





