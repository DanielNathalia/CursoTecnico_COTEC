#Faça um programa que faça o computador jogar JOKENPO (pedra, papel e tesoura) com
#você
from random import randint
from time import sleep


print('''
JO
KE
PO
''')
print('=' * 60)
itens =  ("PEDRA", "PAPEL", "TESOURA")

print('''*** OPÇÕES ***
[0] PEDRA
[1] PAPEL
[2] TESOURA''')

print('=' * 60)
jogador = int(input('Informe a sua opção:'))
print('Jogador: {}'.format(itens[jogador]))
computador = randint(0,2)
print('Computador: {}'.format(itens[computador]))

print('=' * 60)
#O computador escolheu PEDRA
if computador == 0:
 if jogador == 0: #O jogador escoleu PEDRA
    print('O jogo deu EMPATE!')
 elif jogador == 1:  # O jogador escolheu PAPEL
    print('O jogador venceu. PARABÉNS!')
 elif jogador == 2:# O jogador escolheu TESOURA
    print('O computador venceu!')

#O computador escolheu PAPEL
if computador == 1:
 if  jogador == 0: # O jogador escolheu PEDRA
    print('O computador venceu!')
 elif jogador == 1: # O jogador escolheu PAPEL
    print('O joggo EMPATOU!')
 elif jogador == 2: # O jogador escolheu TESOURA
    print('O jogador venceu. PARABÉNS!')

#O computador escolheu TESOURA
if computador == 2:
 if jogador == 0: # O jogador escolheu PEDRA
    print('O jogador venceu. PARABÉNS!')
 elif jogador == 1: # O jogador escolheu PAPEL
    print('O computador venceu!')
 elif jogador == 2: # O jogador escolheu TESOURA
    print('O jogo deu EMPATE!')
print('=' * 60)