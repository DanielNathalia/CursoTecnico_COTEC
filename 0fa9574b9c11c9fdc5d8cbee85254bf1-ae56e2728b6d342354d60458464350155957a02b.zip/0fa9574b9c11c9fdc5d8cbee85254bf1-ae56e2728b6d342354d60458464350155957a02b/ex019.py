#Escreva um programa que pergunte a distancia de uma viaem em km
#calcule o preço da passagem, cobrando R$0,78 por km para viagens ate 200km
#e R$0,53 para viagen mais longas


distancia = int(input('Informe a distancia em km até o destino de sua viagem: '))
#print('A sua viagem será de {} km'.format(distancia))

if distancia <= 200 :
    custo = 0.78 * distancia
else:
    custo = 0.53 * distancia

print('-' * 60)
print('A sua viagem de {}km terá um custo de R${:.2f}'.format(distancia, custo))
print('Desejamos uma BOA VIAGEM!')
print('-' * 60)