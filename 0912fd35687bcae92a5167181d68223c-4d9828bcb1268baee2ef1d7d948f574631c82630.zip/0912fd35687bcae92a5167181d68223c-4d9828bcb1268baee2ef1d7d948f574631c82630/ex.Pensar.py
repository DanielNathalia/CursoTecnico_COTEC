# import random
from random import randint
from time import sleep

computador = randint(0,10) #gera um numero aleatório entre 0 10

print('-'*60)
print('Estou pensando em um número de 0 a 10. Advinhe qual é')
print('-'*60)

acertou = False

while not acertou:
    pessoa = int(input('Qual número eu pensei:'))
    cont += 1

    #compara o numero do comptador com o da pessoa
    if comptador == pessoa:
        print('Você ganhou!')
        acertou = True

    if pessoa < computador:
      print('O numero que pensei é menor.')
    elif pessoa > computador:
      print('O número que pensei é maior')

print('-'*60)
print('O numero que você digitou foi {}, o numero que o computador pensou foi {}'. format(pessoa, computador))
print('-'*60)
