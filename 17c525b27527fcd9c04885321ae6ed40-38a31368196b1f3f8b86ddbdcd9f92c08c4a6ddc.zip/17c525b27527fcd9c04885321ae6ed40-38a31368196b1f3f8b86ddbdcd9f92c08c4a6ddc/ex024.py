#Escreva um programa para aprovar o empréstimo bancário para a compra
#de um casa. O programa vai perguntar o VALOR DA CASA, o SALARIO do
#comprador e em QUANTOS ANOS ele vai pagar

#calcule o valor da prestação mensal sabendo que ela não pode exceder 30%
#do salario ou então o emprestimo será negado

valorcasa = float(input('Informe o valor da casa: R$'))
salario = float(input('Informe  o seu salario: R$'))
prazo = int(input('Informe o prazo do financiamento em anos:'))

valorfinanc = valorcasa / ( prazo * 12)
valormax = salario * ( 30 / 100 )

if valorfinanc <= valormax:
    print('O se financiamento foi aprovado!')
else:
    print('O seu financiamento não foi aprovado pois o valor da parcela excede 30% do seu salario.')