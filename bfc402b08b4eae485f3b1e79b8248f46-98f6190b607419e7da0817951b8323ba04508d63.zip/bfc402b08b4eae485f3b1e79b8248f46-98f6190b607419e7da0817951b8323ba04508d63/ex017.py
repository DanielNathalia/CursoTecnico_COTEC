#Escreva um programa que leia a velocidade do carro
#se ele ultrapassar 80km/h, mostre uma mensagem diendo que ele foi multado
#A multa vai custar R$9,25 por cada km a cima do limite.

velocidade = int(input('Informe a velocidade do carro:'))
#print('A velocidade do carro é de {} km/h'.format(velocidade))

print('-' * 60)
if velocidade > 80 :
    multa = (velocidade - 80) * 9,25
    print('Você está acima da velocidade permitida! Será multado.')
    print('O valor da sua multa será de R$ {}'.format(multa))
else:
    print('Parabéns você está dirigindo no limite de velocidade permitido')
print('-' * 60)